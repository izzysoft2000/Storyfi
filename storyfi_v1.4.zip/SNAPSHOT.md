# Storyfi — Implementation Snapshot
> Read this file at the start of every session before touching any code.
> Update this file at the end of every session.
> Last updated: 2026-04-21 (session 4)
> Current phase: v1.3 — Mobile UI polish

---

## What Storyfi Is
A professional, browser-native multi-voice audio production studio. Transforms Markdown scripts into polished audio using high-end TTS engines (MiniMax, ElevenLabs, OpenAI). Features a "Cinema Noir" editorial interface with real-time word-level synchronisation, per-character performance controls, and a draggable multi-pane workspace. Built with Vue 3 + Tiptap + Pinia + IndexedDB.

---

## Tech Stack
| Layer | Choice |
|---|---|
| Framework | Vue 3, Composition API, `<script setup>` |
| Build | Vite 6 |
| Editor | Tiptap v2 via `@tiptap/vue-3` |
| State | Pinia (project.js + generation.js + playback.js) |
| Storage | IndexedDB via `idb` library |
| File output | File System Access API (per-project folder) |
| PWA | vite-plugin-pwa + Workbox |
| Audio engine | lamejs (gapless 128kbps CBR MP3) |
| Playback | Web Audio API (`AudioContext` + `AudioBufferSourceNode`) |
| Drag & drop | vuedraggable@next (SortableJS wrapper) |
| Hosting | Cloudflare Pages |
| Fonts | Playfair Display (display), DM Sans (UI), JetBrains Mono (mono) |

---

## Project Structure

```
storyfi/
├── index.html
├── vite.config.js
├── package.json
├── public/
│   └── manifest.json
└── src/
    ├── main.js                        — Vue app entry, Pinia init
    ├── App.vue                        — root component, hash router (#/project/:id), global CSS tokens
    ├── views/
    │   ├── LibraryView.vue            — project grid + New Project card; no import/new buttons in header
    │   └── EditorView.vue             — dockable workspace shell: toolbar, columns, status bar
    ├── panels/
    │   ├── CastPanel.vue              — voice role CRUD, per-role provider/voice/performance/model settings (no header — in DockablePanel)
    │   └── PlaylistPane.vue           — group rows, sentence sub-rows, Generate/Export toolbar, AudioPlayerBar
    ├── editor/
    │   ├── StoryEditor.vue            — Tiptap editor, BubbleMenu tagging, MD import, highlight decorations (no toolbar — in DockablePanel bar-right)
    │   ├── splitter.js                — sentence extraction, char-limit splitting, extractTaggedSpans()
    │   └── extensions/
    │       ├── VoiceTag.js            — custom Mark: highlights tagged text with role colour
    │       └── SegmentBreak.js        — custom Node: manual segment break marker (§)
    ├── store/
    │   ├── db.js                      — IndexedDB schema (v2: +voice_previews), saveProject strips Vue Proxy
    │   ├── project.js                 — Pinia: active project, cast mutations, defaultVoiceAssignment(), reorderCast()
    │   ├── generation.js              — Pinia: build groups, sentence queue, stitch, disk write
    │   └── playback.js                — Pinia: transport state, RAF loop, highlight sync
    ├── tts/
    │   ├── provider.js                — registry, voice cache, withConcurrency(), withRetry()
    │   ├── minimax.js                 — MiniMax T2A v2, per-role model, hex decode, GroupId as query param
    │   ├── openai.js                  — OpenAI TTS, binary MP3, no word timings
    │   └── browser.js                 — SpeechSynthesis, preview only, no MP3 export
    ├── audio/
    │   ├── timestamps.js              — getBlobDurationMs() 3-tier, computeSentenceTimings(), formatDuration()
    │   └── stitcher.js                — lamejs gapless MP3 encode
    ├── storage/
    │   ├── crypto.js                  — Web Crypto API: PBKDF2+AES-GCM key encryption
    │   ├── filesystem.js              — File System Access API: pickFolder, write, read, exists
    │   ├── quota.js                   — StorageManager: getQuotaInfo(), requestPersistentStorage()
    │   └── synccheck.js               — disk vs IDB divergence detection on project open
    ├── modals/
    │   ├── SettingsModal.vue          — API key entry per provider, active provider selector
    │   ├── FolderPromptModal.vue      — first-generation output folder prompt, per-project
    │   ├── SyncWarningModal.vue       — repair options: re-write / re-import / mark for regen
    │   └── ExportModal.vue            — ZIP/JSON/HTML/CSV export with live progress bar
    ├── components/
    │   ├── StorageBar.vue             — quota bar; compact prop for status bar inline mode
    │   ├── Toast.vue                  — global toast stack
    │   ├── ConfirmModal.vue           — reusable confirm dialog
    │   ├── AudioPlayerBar.vue         — player transport: play/pause, stop, progress scrub, time display
    │   └── DockablePanel.vue          — panel wrapper: title bar, ⠿ drag handle, bar-right slot, drop zones
    ├── export/
    │   └── exporter.js                — exportZip / exportJSON / exportHTML / exportCSV
    ├── composables/
    │   ├── useOnlineStatus.js         — shared reactive online/offline state (navigator.onLine + events)
    │   ├── usePanelLayout.js          — panel layout state, mutations, localStorage persistence
    │   └── usePanelDrag.js            — ghost element, drag state, drop zone detection (non-reactive DOM)
    └── utils/
        ├── uuid.js                    — crypto.randomUUID()
        ├── debounce.js                — debounce(fn, ms)
        └── colors.js                 — ROLE_COLORS[], nextRoleColor(), hexAlpha()
```

---

## IndexedDB Schema (storyfi_db v2)
```
projects        keyPath: "id"          — Project record incl. paragraphGroups[].sentences[]
sentences       keyPath: "id"          — Sentence records, index: paragraphGroupId
audio_sentences keyPath: "sentenceId"  — Raw sentence MP3 Blobs
audio_stitched  keyPath: "groupId"     — Stitched paragraph MP3 Blobs
api_keys        keyPath: "providerId"  — Encrypted API key records
settings        keyPath: "key"         — appPreferences, activeProvider
voice_previews  keyPath: "key"         — Cached preview MP3 Blobs, key: "{providerId}_{voiceId}"
```

---

## Data Model (key interfaces)

```typescript
Project {
  id, title, createdAt, updatedAt,
  sourceMarkdown, editorState,        // Tiptap JSON doc
  cast: VoiceRole[],
  paragraphGroups: ParagraphGroup[],
  audioSizeBytes,
  outputFolderHandle,                  // FileSystemDirectoryHandle | null
  outputFolderName,
  outputFolderPromptDismissed,
  persistenceGranted
}

VoiceRole {
  id: string,                         // uuid() — never index-based (Bug Fix #11)
  label: string,
  color: string,
  voiceAssignment: VoiceAssignment    // never null (Bug Fix #12)
}

VoiceAssignment {
  providerId: string,                 // 'minimax' | 'openai' | 'elevenlabs' | 'browser'
  voiceId:    string | null,
  voiceName:  string | null,
  settings: {
    speed:   number,                  // 0.5 – 2.0
    pitch:   number,                  // -12 – 12 (not sent to OpenAI)
    volume:  number,                  // 0.0 – 2.0 (default 1.0)
    emotion: string,                  // '' | 'neutral' | 'happy' | 'sad' | 'angry'
    model:   string,                  // MiniMax model string (see models below)
  }
}

ParagraphGroup {
  id, roleId, roleLabel, color, order, spanKey,
  sentences: Sentence[],
  sentenceIds: string[],
  stitchStatus: "pending"|"stitching"|"ready"|"error",
  stitchedAudioKey, stitchedDiskFilename,
  totalDurationMs, startMs, endMs
}

Sentence {
  id, paragraphGroupId, roleId, text, sentenceIndex,
  status: "pending"|"generating"|"ready"|"error"|"stale",
  audioKey, durationMs, startMs, endMs,
  editorFrom, editorTo,
  wordTimings: WordTiming[] | null,   // { word, start_ms, end_ms } from MiniMax
  splitWarning
}
```

---

## MiniMax Models (all 8 current)
```
speech-2.8-hd     — Premium  (latest, best quality)
speech-2.8-turbo  — Standard (latest turbo)
speech-2.6-hd     — Premium  ← default for new roles
speech-2.6-turbo  — Standard
speech-02-hd      — Standard (legacy)
speech-02-turbo   — Budget   (legacy)
speech-01-hd      — Budget   (legacy)
speech-01-turbo   — Budget   (cheapest)
```

Default for new roles: `speech-2.6-hd`

Emotion payload rule — omit field entirely when empty string:
```javascript
...(settings?.emotion ? { emotion: settings.emotion } : {}),
```

---

## Critical Bug Fixes — DO NOT REVERT

### 1. saveProject() — strips Vue Proxy before IDB write
```javascript
const { outputFolderHandle, ...serializable } = project
const plain = JSON.parse(JSON.stringify(serializable))
await db.put('projects', { ...plain, outputFolderHandle, updatedAt: Date.now() })
```

### 2. MiniMax audio is HEX encoded, not base64
```javascript
const isHex = /^[0-9a-fA-F]+$/.test(trimmed) && trimmed.length % 2 === 0
return isHex ? hexToBlob(trimmed) : base64ToBlob(trimmed)
```

### 3. MiniMax GroupId — query param not header (CORS)
```javascript
const url = groupId
  ? `https://api.minimax.io/v1/t2a_v2?GroupId=${groupId}`
  : `https://api.minimax.io/v1/t2a_v2`
```

### 4. Resizable pane — pure DOM, no Vue reactive state during drag
Direct DOM style mutation during mousemove. No `ref()` update → no Vue re-render → no `__vnode null` crash.

### 5. getBlobDurationMs() — 3-tier with timeouts
Tier 1: HTML `<audio>`. Tier 2: `AudioContext` with 5s `Promise.race`. Tier 3: size estimate.

### 6. generation.js — all imports static, none dynamic
No `await import()` inside async loops. Dynamic imports in concurrent tasks cause silent hangs.

### 7. Playlist pane layout — flexbox not CSS grid
`display: flex; flex-direction: row` on shell. CSS grid with reactive `gridTemplateColumns` is unreliable with Vue scoped styles.

### 8. Web Audio objects — never in Pinia reactive state
`AudioContext`, `AudioBufferSourceNode`, `AudioBuffer[]` in module-level `let` vars in `playback.js`. Vue Proxy-wrapping breaks `suspended` state and `onended` callbacks.

### 9. Playback highlight decorations — transient, never saved
Driven by `editor.view.dispatch(tr.setMeta(...))`. Never written to Tiptap JSON doc. Never triggers auto-save debounce.

### 10. decodeAudioData — 10s timeout
```javascript
const audioBuf = await Promise.race([
  _audioCtx.decodeAudioData(arrayBuf),
  new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 10_000)),
])
```

### 11. Role IDs use uuid(), never array index
```javascript
// store/project.js — addRole()
const id = uuid()  // was: `actor_${idx}` — caused double-delete after add+delete cycle
```
`actor_${cast.length}` reuses IDs after deletion. Example: delete Actor 1 (len→2), add new role → gets id `actor_2`, colliding with existing Actor 2. `deleteRole` filters by id, removing both. uuid() is collision-proof.

### 12. voiceAssignment is never null
`addRole()` and `createBlankProject()` always call `defaultVoiceAssignment()`. CastPanel has `watch(roles, normalizeRoles, { immediate: true })` that patches roles loaded from older saves (backfills null voiceAssignment and any missing settings keys including `model`).

```javascript
// store/project.js
function defaultVoiceAssignment() {
  return {
    providerId: 'minimax', voiceId: null, voiceName: null,
    settings: { speed: 1.0, pitch: 0, volume: 1.0, emotion: '', model: 'speech-2.6-hd' },
  }
}
```

### 13. unsetVoiceTag — must extendMarkRange first
Without a text selection (cursor-only mode), `unsetVoiceTag()` alone only operates at the cursor point and leaves the mark visible. Always extend to the full mark range first:
```javascript
editor.chain().focus().extendMarkRange('voiceTag').unsetVoiceTag().run()
```
`extendMarkRange('voiceTag')` walks outward from the cursor to the mark boundaries before unsetting. Works correctly for both cursor-only and text-selection modes.

---

## CastPanel — Drag to Reorder
Cast roles are reorderable via drag-and-drop using `vuedraggable@next`.

- `⠿` drag handle on each card — invisible at rest, fades in on card hover
- `ghost-class="role-card--ghost"` — faint dashed purple tint at drop target
- `animation: 180` — smooth SortableJS slide animation
- `reorderableCast` writable computed: getter returns `store.cast`, setter calls `store.reorderCast(newOrder)`
- `store.reorderCast(newOrder)` replaces `project.value.cast` and calls `markDirty()`
- Cast order is cosmetic only — generation order is driven by document position, not cast order

---

## CastPanel — Performance Settings (⚙️ gear icon)

| Field | Shown when | Notes |
|---|---|---|
| Speed | Always | Range 0.5–2.0 |
| Volume | Always | Range 0.0–2.0, default 1.0 |
| Pitch | Not OpenAI | Range -12–12 |
| Model | MiniMax only | All 8 models, grouped by generation with cost badge |
| Emotion | MiniMax only | Includes "— None —" (`value=""`) to omit from API payload |

Model cost badge colours: purple = Premium, muted = Standard, green = Budget.
`MODEL_TIERS` map in CastPanel drives badge label + colour class.
`normalizeRoles` watcher backfills `model` (and all keys) for old saves.

---

## BubbleMenu — Two Modes (StoryEditor.vue)

`shouldShowBubble` triggers on text selection **or** cursor inside a voiceTag mark.

**Selection mode** (`hasSelection = true`):
- "Tag as:" label + all role chips
- "✕ Remove" if selection is already tagged
- "§" segment break button

**Cursor-in-tag mode** (`hasSelection = false`, cursor inside mark):
- "Tagged span:" label
- "✕ Remove" only — role chips and § hidden

`hasSelection` computed reads `editor.state.selection.{from, to}` directly.
Remove always uses `extendMarkRange('voiceTag')` before `unsetVoiceTag()` (Bug Fix #13).

---

## LibraryView — Current UX
- Header contains brand + Install App pill only — no action buttons
- Project grid uses `repeat(auto-fill, minmax(300px, 1fr))`
- "New Project" card is always the last grid cell — dashed border, "+" icon, accent on hover
- Empty state: grid renders with just the New card (no separate branch)
- MD import lives in the Editor toolbar only (StoryEditor.vue) — removed from Library entirely

---

## Voice Preview System (CastPanel)

Preview buttons appear in two places:
- **Role card** — small ▶ next to the assigned voice chip. Only shown when a voice is assigned.
- **Voice picker modal** — ▶ on each voice row, fades in on hover.

Three button states: ▶ idle, spinner (generating), ■ playing. Clicking ■ stops. While one voice loads, all other buttons are disabled.

**Cache:** `voice_previews` IDB store (schema v2). Key: `{providerId}_{voiceId}`.
Preview text: `"Hello. How does this sound to you?"` — always uses default settings so the cache key stays stable.
Cost: ~24KB per voice. 130 MiniMax voices ≈ 3MB if all previewed.

**Cached indicator:** Cached = accent purple at 65% opacity (always visible). Uncached = muted gray (fades in on hover). Tooltip: "Play preview (cached)" vs "Generate preview".

`cachedPreviewIds` — `Set<voiceId>` loaded on picker open via `getAllVoicePreviewKeys()`, filtered by provider prefix. Updated live on new generation.

`_previewAudio` — module-level `Audio` element, not reactive. Cleaned up on picker close.

New db.js exports: `getVoicePreview`, `saveVoicePreview`, `deleteVoicePreview`, `getAllVoicePreviewKeys`.

---

## Voice Picker — Language & Gender Filters

Two filter rows sit between the search input and the voice list.

**Language pills** — derived from `availableLanguages` computed (English first, rest alpha). Only shown when more than one language is present. Clicking active pill returns to All.

**Gender pills** — always shown: Both / ♂ Male / ♀ Female.

All three filters (language + gender + search text) combine with AND logic.
Both filters reset when the picker opens.

**Language badges on each row:**
- `EN` badge — very faint (opacity 0.45)
- Non-English badge — `--color-highlight` purple (opacity 0.75), visually distinct
- Gender badge — faint, same style as EN

18 language codes: `en fr es de it ru ja ko zh yue pt ar hi id nl pl tr uk`
`LANG_LABELS` map provides short code (badge/pill) + full name (tooltip).

---

## Online / Offline Status

`src/composables/useOnlineStatus.js` — module-level shared `ref(navigator.onLine)`. Window events registered once on first consumer mount, removed on last unmount.

**Status bar** (bottom of workspace — v1.2 moved from sidebar):
```
[████░ 3.1MB / 10GB  Manage]   ·   ● Saved   ● Online
```
Saved dot and online dot sit in the status bar flex row alongside the compact StorageBar.

**On connection change:**
- Drop → warning toast 5s: "You're offline — audio generation unavailable"
- Return → success toast 2.5s: "Back online"

**Disabled when offline:** ▶ Generate button, 🔄 per-group regenerate buttons.
**Always works offline:** editor, tagging, cached audio playback, export, settings.
Voice preview generation fails gracefully offline; cached previews still play.

---

## Dockable Panel System (v1.2)

### Architecture
Three draggable panels — **Cast**, **Playlist**, **Editor** — arranged in dynamic columns.
Fixed **Toolbar** at top, fixed **Status Bar** at bottom. Both immovable.

### New files
| File | Role |
|---|---|
| `src/composables/usePanelLayout.js` | Layout state (columns + widths), localStorage persistence, mutations |
| `src/composables/usePanelDrag.js` | Ghost element (raw DOM), drag events, drop zone detection |
| `src/components/DockablePanel.vue` | Panel wrapper: title bar, ⠿ handle, `#bar-right` slot, horizontal drop zones |

### Layout model (`usePanelLayout`)
```javascript
// localStorage key: 'storyfi_panel_layout_v1'
{
  columns: [
    { id: string, panels: ('cast'|'playlist'|'editor')[] },
    ...
  ],
  columnWidths: { [colId]: number }  // undefined = flex:1
}
```
Default: `[{ id:'col-left', panels:['cast','playlist'] }, { id:'col-right', panels:['editor'] }]`

Mutations: `movePanel(panelId, targetColId, index)`, `insertInNewColumn(panelId, refColId, side)`, `setColumnWidth(colId, px)`, `resetLayout()`
Empty columns auto-removed after every mutation. Layout validated on load (all 3 panels must be present).

### Drag system (`usePanelDrag`) — Bug Fix #4 pattern
All mouse state is non-reactive module-level vars. Only `draggingPanelId` and `activeDropZone` are reactive refs (consumed by templates for highlight classes).

Ghost element: raw `document.createElement` div, CSS-variable styled, `position:fixed`, `pointerEvents:none`, follows cursor via `style.left/top` on every `mousemove`.

Drop zone detection: `querySelectorAll('[data-drop-zone]')` on every `mousemove`, checks `getBoundingClientRect()` against cursor position. No `mouseenter`/`mouseleave` — position-based is more reliable.

Drop zone types:
- `{ type: 'in-col', colId, index }` — insert in column at index (horizontal lines between panels)
- `{ type: 'new-col', refColId, side: 'left'|'right' }` — create new column (vertical lines at column edges)

### DockablePanel
- `⠿` drag handle in title bar — opacity 0 at rest, 0.75 on card hover
- `#bar-right` slot for per-panel toolbar items
- Horizontal drop zones (6px, `dz--h`) appear above/below panel during drag
- Panel dims to `opacity: 0.35` while being dragged
- `startDrag(panelId, event, onDrop)` called on handle `mousedown`

### EditorView workspace shell
**Global toolbar** (fixed top, 40px):
```
← Library  |  [Project Title]                    ⊞ Reset Layout  |  ⚙ Settings
```

**Editor panel bar-right slot:**
```
⠿ Editor    ↑ Import  |  B  I  |  §  [N chars]
```

**Playlist panel toolbar** (inside panel, not in DockablePanel bar):
```
▶ Generate   ↓ Export
```

**Status bar** (fixed bottom, 30px):
```
[████░ 3.1MB / 10GB  Manage]   ●  ● Saved   ● Online
```
StorageBar uses `compact` prop for inline horizontal layout.

**Column resize — `_activeResize` reactive ref approach:**

All resize state is non-reactive module-level vars. `_activeResize = ref(null)` is the single reactive driver — `colStyle` reads it to return live drag widths. No direct DOM style manipulation.

```javascript
// Non-reactive vars (Bug Fix #4 pattern)
let _colResizing   = false
let _colResizeId   = null
let _colLeftEdge   = 0      // active column's getBoundingClientRect().left
let _colLastW      = 0      // updated every onMove, used on mouseup (not offsetWidth)
let _leftSnapshots = {}     // { colId: renderedWidth } for all columns LEFT of handle

const _activeResize = ref(null) // { colId, width } — drives colStyle during drag
```

**`colStyle(colId)` logic:**
1. If `_activeResize.value.colId === colId` → fixed at drag width
2. If `_activeResize` is set AND this column is LEFT of active → use `_leftSnapshots[colId]` (snapshot from drag-start), fallback to `columnWidths`, then flex
3. If `_activeResize` is set AND this column is RIGHT of active → `flexGrow:1` (absorbs change)
4. No active resize → use `columnWidths` if saved, else `flexGrow:1`

**Width formula:** `width = clientX - column.getBoundingClientRect().left` — avoids all `offsetWidth` timing issues. Column left edge captured once at `mousedown`, never changes during drag.

**Max width:** `container.offsetWidth - 180 - 5` (container minus min other-col width minus handle). Hardcoded `700` was too small for wide screens and caused the "jump to left" bug.

**`onUp` persistence:**
```javascript
// Spread snapshots first (pins left-side columns even if they had no saved width)
const newWidths = { ...layout.value.columnWidths, ..._leftSnapshots }
// Clear widths for columns to the RIGHT (they remain flexible)
layout.value.columns.forEach((col, idx) => {
  if (idx > resizedIdx) delete newWidths[col.id]
})
newWidths[_colResizeId] = _colLastW
layout.value = { ...layout.value, columnWidths: newWidths }
```

**editorRef binding:** uses named function `setEditorRef(el)` instead of inline arrow in `v-for` (Bug Fix #14).

### Bug Fix #14 — named ref callback in v-for (not inline arrow)
```javascript
// WRONG — inline arrow in v-for gets stale closure on teardown:
// :ref="el => { editorRef.value = el || null }"

// CORRECT — named function, stable reference:
function setEditorRef(el) {
  if (editorRef) editorRef.value = el ?? null
}
// In template: :ref="setEditorRef"
```
Vue calls ref callbacks with `null` on component unmount. Inline arrows inside `v-for` have a closure-capture timing bug where the reactive scope is partially destroyed before the cleanup call fires. Named functions avoid this.

### Bug Fix #15 — Column resize: width = mouseX − leftEdge, not offsetWidth
`offsetWidth` on a `flex-basis: 0px` column can return 0 or incorrect values before layout settles. Computing `width = clientX - col.getBoundingClientRect().left` is always correct — the column's left edge never moves during a drag.

### Bug Fix #16 — Column resize: hardcoded 700px max caused jump-to-left
`Math.min(700, ...)` clamped columns wider than 700px (editor with `flexGrow:1` was ~750px) to 700px on first `mousemove`. Max is now `container.offsetWidth - 180 - 5`.

### Bug Fix #17 — Column resize: _activeResize ref, not direct DOM manipulation
Setting `el.style.flexBasis` directly during drag was overwritten by Vue re-renders triggered by `activeDropZone` changes. `_activeResize = ref(null)` drives `colStyle` so Vue applies the drag width as the authoritative value.

### Bug Fix #18 — Column resize: left-side column snapshots
When dragging a right handle in a 3-column layout where left-side columns have no saved `columnWidths` entry (e.g., newly created via drag), those columns were `flexGrow:1` during the drag and expanded alongside the right column. Fix: capture `getBoundingClientRect().width` for all left-side columns at `mousedown` into `_leftSnapshots`, use them in `colStyle` to pin those columns, persist them to `columnWidths` on `mouseup`.

### Bug Fix #19 — AudioPlayerBar play button disabled after generation
`playback.hasAudio` is only true after `loadAndPlay()` decodes buffers. Button was disabled even when generated audio existed in IDB. Fixed with `hasReadyAudio = playback.hasAudio || props.groups.some(g => g.stitchStatus === 'ready')`.

### Bug Fix #20 — waveformData getter always returned null
Pinia getters only recompute when their `state` dependencies change. `() => _waveformData` had no state dependency so was never recomputed. Fix: `(state) => state.waveformVersion > 0 ? _waveformData : null` — getter now depends on `waveformVersion` and recomputes when it increments.

### Bug Fix #21 — New tag above existing groups missing from playlist
`gen.buildGroupsFromDoc()` was only called at Generate time. Tags added above existing generated groups never updated `gen.groups` order. Fix: `watch(taggedSpans, ...)` in EditorView calls `gen.buildGroupsFromDoc(doc, charLimit)` on every tagging change, guarded by `gen.groups.length > 0`. `buildGroupsFromDoc` preserves `stitchStatus === 'ready'` groups and only reorders/adds pending ones.

---
```
--color-bg         #0e0c18      --font-display  'Playfair Display'
--color-surface    #1a1625      --font-ui       'DM Sans'
--color-border     #2e2a42      --font-mono     'JetBrains Mono'
--color-accent     #7c5cbf
--color-highlight  #c084fc
--color-text       #f0eeff
--color-text-muted #8b85a8
--color-success    #4ade80
--color-warning    #facc15
--color-error      #f87171
```

---

## Waveform Visualisation (AudioPlayerBar)

Waveform canvas replaces the thin `player-track` progress div entirely. 52px tall, full panel width, scrubable.

**`playback.js` additions:**
- `_waveformData` — module-level `Float32Array | null` (non-reactive — never Proxy-wrap typed arrays)
- `WAVEFORM_BARS = 200` — downsample target
- `buildWaveformData(buffers, bars)` — pure function: merges channels (averaged), RMS-downsamples to `bars` values, normalises 0→1. Called after all buffers decoded in `loadAndPlay`.
- `waveformVersion: 0` — reactive state, incremented on each rebuild, drives getter reactivity
- `waveformData` getter — `(state) => state.waveformVersion > 0 ? _waveformData : null`
  - **Must depend on `state.waveformVersion`** — a plain `() => _waveformData` getter has no reactive dependency and always returns null (Bug Fix #20).
- `_waveformData = null` reset in `_cleanup()`

**`AudioPlayerBar.vue`:**
- `<canvas ref="canvasEl">` — DPR-aware, redraws via `watch(() => [playback.progress, playback.waveformVersion], drawWaveform)`
- `ResizeObserver` on parent redraws on panel resize
- Colours: purple played (`#7c5cbf`), muted unplayed (`rgba(255,255,255,0.12)`), light-purple playhead (`#a78bfa`)
- Placeholder: 40 sine-wave-height bars at 50% opacity before waveform decoded (`v-if="!playback.waveformData"`)
- Scrub: `mousedown`/`touchstart` on canvas → `seekToMs()` or repositions `currentMs` if stopped
- Controls row: `[time] [Stop] [Play] [time]` — single row, no separate progress row

---

## Phase / Feature Status
| Area | Feature | Status |
|---|---|---|
| Core | PWA shell, Library, IndexedDB | ✅ |
| Core | Tiptap editor, VoiceTag, SegmentBreak | ✅ |
| Core | MiniMax/OpenAI/ElevenLabs/Browser TTS | ✅ |
| Core | Sentence splitting, lamejs stitching, disk output | ✅ |
| Core | Playlist + sync-on-open divergence repair | ✅ |
| Core | Resizable dual-pane workspace | ✅ |
| Phase 4 | Web Audio playback, seek, scrub | ✅ |
| Phase 4 | Word highlight (MiniMax/ElevenLabs) | ✅ |
| Phase 4 | Sentence highlight fallback (OpenAI) | ✅ |
| Phase 5 | ZIP / JSON / HTML / CSV export | ✅ |
| Phase 6 | Cloudflare Pages deployment | ✅ |
| Polish | CastPanel — all CSS tokens, no hardcoded hex | ✅ |
| Polish | Per-role MiniMax model selector (all 8 models) | ✅ |
| Polish | Emotion "None" option to unset | ✅ |
| Polish | Volume slider (0–2.0) in advanced settings | ✅ |
| Polish | Library New Project card, header cleanup | ✅ |
| Polish | Cast drag-to-reorder (vuedraggable@next) | ✅ |
| Polish | BubbleMenu cursor-in-tag mode (Remove only) | ✅ |
| Polish | Voice preview with IDB cache (db v2) | ✅ |
| Polish | Cached preview visual indicator (purple = cached) | ✅ |
| Polish | Voice picker language + gender filter pills | ✅ |
| Polish | Language & gender badges on voice rows | ✅ |
| Polish | Online/offline status dot + toast + disabled states | ✅ |
| v1.2 | Dockable panel system (drag, ghost, drop zones, columns) | ✅ |
| v1.2 | Panel layout localStorage persistence | ✅ |
| v1.2 | Column resize handles — full directional snapshot system | ✅ |
| v1.2 | Global toolbar (nav + title + app controls) | ✅ |
| v1.2 | Editor toolbar in DockablePanel bar-right slot | ✅ |
| v1.2 | Status bar (StorageBar compact + Saved + Online) | ✅ |
| Bug #11 | Role ID collision (uuid vs index) | ✅ |
| Bug #12 | voiceAssignment null crash on add/delete | ✅ |
| Bug #13 | unsetVoiceTag needs extendMarkRange first | ✅ |
| Bug #14 | Named ref callback in v-for (not inline arrow) | ✅ |
| Bug #15 | Column resize width = mouseX − leftEdge (not offsetWidth) | ✅ |
| Bug #16 | Column resize 700px max too small (now dynamic) | ✅ |
| Bug #17 | Column resize via _activeResize ref (not direct DOM) | ✅ |
| Bug #18 | Left-column snapshots for unsaved-width columns | ✅ |
| Bug #19 | AudioPlayerBar disabled after generation (hasReadyAudio) | ✅ |
| Bug #20 | waveformData getter not reactive (must depend on waveformVersion) | ✅ |
| Bug #21 | New tag above existing groups missing from playlist until Generate | ✅ |
| v1.2 | Waveform visualisation in AudioPlayerBar | ✅ |
| v1.3 | Mobile panel toolbar CSS (m-panel-toolbar, m-tool-btn, etc.) | ✅ |
| v1.3 | Offline globe indicator (🌐) replaces floating status dots | ✅ |
| v1.3 | Swipe-between-panels removed — bottom tab nav only | ✅ |
| v1.3 | Edge swipe prevention (CSS overscroll-behavior-x + JS edge guard) | ✅ |
| v1.3 | Mobile editor toolbar hijack on text selection | ✅ |
| v1.3 | BubbleMenu overflow dropdown (first 3 chips + +N ▾) | ✅ |
| Bug #22 | swipeDelta referenced in setActivePanel after swipe removal | ✅ |
| Bug #23 | Mobile toolbar CSS classes defined in template but never styled | ✅ |
| Bug #24 | Edge touch guard blocked ← back button (now exempts interactive elements) | ✅ |
| Backlog | Scene/Act/Chapter hierarchy | ⬜ |
| Backlog | Auto-scroll teleprompter during playback | ⬜ |
| Backlog | SRT/VTT subtitle export | ⬜ |
| Backlog | Cloudflare Worker — OAuth proxy + MiniMax API proxy | ⬜ |
| Backlog | Google Drive integration (requires Worker for token exchange) | ⬜ |

---

## Backlog Notes

### Mobile UI
Swipe left/right to cycle panels (Editor → Cast → Playlist). Dot indicators + tappable.
Detected via `window.matchMedia('(max-width: 768px)')`. Desktop layout completely unaffected.
`showDirectoryPicker()` not supported on iOS (any browser) — falls back to ZIP export automatically via existing `hasFileSystemAccess()` guard. Build mobile before Google Drive — Drive is more valuable on mobile.

### Cloudflare Worker + Google Drive
One Worker solves two long-standing backlog items:
- `/api/minimax` — proxies TTS requests, hides API key from browser bundle
- `/api/oauth/google` — handles OAuth 2.0 token exchange, holds client secret server-side
- `/api/drive/upload` — accepts blob, writes to user's Google Drive

Pure client-side OAuth is insecure (client secret would be in JS bundle). Worker is required.
Google Drive is the natural "save files" answer on iOS where File System Access API is unavailable.
Build order: Mobile UI → Cloudflare Worker → Google Drive.

---
1. Attach or paste this `SNAPSHOT.md`
2. Say what you want to work on
3. Claude reads this file first, then proceeds without needing chat history

## How to End a Session
Ask Claude: "Update SNAPSHOT.md for this session" — Claude generates the updated file.

---

## Auto-Tag Feature (COMPLETED)

### Overview
Two entry points: ⚡ **Auto-tag from script** button in CastPanel (full doc), ⚡ **Auto-tag** in BubbleMenu (selection only). Both merge with existing tags (skips already-tagged spans) and report unmatched labels as a toast. `[LABEL]` text left untagged; only speech text after it gets voiceTag mark applied.

### Files
- `src/editor/autoTagger.js` — `buildAutoTagOperations(editor, roles, options?)` returns `{ operations, found, unmatched }`
- `src/panels/CastPanel.vue` — ⚡ button, `defineEmits(['auto-tag'])`
- `src/editor/StoryEditor.vue` — `applyAutoTagOps(operations, onComplete)` + `applyAutoTag(roles)` + `syncGroups(buildFn, charLimit)` in `defineExpose`
- `src/views/EditorView.vue` — `onAutoTag()`, `onDocUpdated()`, `applyAutoTagQueue()`

### Architecture — Key Rules
1. `buildAutoTagOperations` returns ops, never applies them directly
2. `applyAutoTagOps` runs the entire setTimeout queue inside StoryEditor's own closure
3. `capturedEditor = editor.value` captured at call start — stable across async re-renders
4. `onComplete(doc, json)` — BOTH live doc and JSON come from capturedEditor
5. `syncGroups(buildFn, charLimit)` — reads `editor.value.state.doc` inside StoryEditor's closure; never cross-component boundary

### Critical bugs resolved
- **Split-node labels:** `[NARRATOR]` with code mark is a separate node with no text after `]`. Fix: `pendingRole` in `buildAutoTagOperations` — if [LABEL] has no taggable text, hold the role and apply it to the NEXT sibling text node.
- **Dual StoryEditor instance:** StoryEditor mounts twice during project load. The `capturedEditor` fix ensures the correct (marks-applied) editor is used throughout the queue.
- **`getEditor()` spam:** `isBold`/`isItalic` computed properties called `getEditor()` on every update — 80+ calls during a queue. Replaced with `ref(false)`.
- **Vue proxy stripping marks:** docs passed through `emit()` lost voiceTag marks. All group rebuilds now use `syncGroups` or `applyAutoTagOps` which read the doc inside StoryEditor's closure.

---

## Mobile UI (COMPLETED)

### Architecture
`useMobileLayout.js` composable — detects `isMobile` (< 768px), manages `activePanel` ('editor'|'playlist'), `castOpen` drawer state, swipe gesture handling. Last panel persisted to `localStorage` key `storyfi_mobile_last_panel`.

### Layout — Portrait
- Fixed 48px top bar: `← | Title | ⚙`
- Full-screen swipeable panel track (`200vw` wide, `translateX(-N*100vw)`)
- Cast slide-in drawer (`position: fixed`, left edge)
- 56px bottom bar: `[🎭 Cast] [context actions] [✏️ Editor] [▶ Playlist]`
- Context actions: Editor → `↑ B I §` | Playlist → empty (buttons already in panel)

### Swipe
- Axis lock: vertical scroll wins if `|dy| > |dx|`
- 50px threshold to commit panel switch
- Rubber-band resistance (×0.35) at edge panels
- `translateX(calc(-N*100vw + Δpx))` — uses `vw` not `%` (% is relative to track width)

### Safe Area — Final Solution
- `html, body, #app { height: 100vh }` — fills viewport in standalone PWA
- `@media (display-mode: standalone)` gates all `env(safe-area-inset-*)` usage
- No safe-bottom filler div needed — iPhone 12 mini has no visible home indicator pill in PWA mode
- `viewport-fit=cover` in `index.html` required for env() to work in standalone
- Apple meta tags in `index.html`: `apple-mobile-web-app-capable`, `apple-touch-icon`, etc.

### Files Changed
- `src/composables/useMobileLayout.js` (new)
- `src/views/EditorView.vue` — mobile layout branch + safe area CSS
- `src/views/LibraryView.vue` — mobile grid fix, safe area, PWA install hint
- `src/App.vue` — `height: 100vh`, removed duplicate `beforeinstallprompt` handler
- `public/manifest.json` — removed `orientation: landscape-primary`
- `index.html` — `viewport-fit=cover`, Apple PWA meta tags

### Key Debug Finding
Tested via debug button: `standalone (media): true`, `env(safe-area-bottom): 29px`, `innerH - view: 0px`. Layout was always correct — the perceived gap was the home indicator zone. Removed the filler since iPhone 12 mini PWA has no visible pill.

---

## v1.3 Mobile Polish (session 4 — 2026-04-21)

### Files changed
| File | What changed |
|---|---|
| `src/views/EditorView.vue` | Panel toolbar CSS, offline globe, selection-mode toolbar, swipe removal, edge guard |
| `src/composables/useMobileLayout.js` | All swipe code removed, simplified trackStyle + setActivePanel |
| `src/editor/StoryEditor.vue` | showBubble prop, selection-change emit, overflow dropdown, exposed tag actions |
| `src/App.vue` | overscroll-behavior-x: none, onEdgeTouch guard, fixed duplicate onMounted |

### Mobile toolbar — two-mode system
Editor panel toolbar now has two modes driven by `mobileSelection` reactive state in EditorView:

**Normal mode** (no selection, no cursor-in-tag):
```
↑ Import | B  I  §  (dimmed, pointer-events:none)  | charCount
```

**Selection mode** (text selected or cursor inside tag):
- Toolbar gets subtle purple tint, `overflow-x: auto`, `flex-wrap: nowrap`
- Scrollable row: all role chips → divider → ✕ (if tagged) → § → ⚡
- Cursor-in-tag only (no selection): "TAGGED:" + "✕ Remove"

Architecture:
- `StoryEditor` emits `selection-change: { hasSelection, selectionIsTagged }` via `onSelectionUpdate` Tiptap callback
- `EditorView` receives it via `@selection-change="onMobileSelectionChange"` → updates `mobileSelection` reactive object
- `:show-bubble="false"` passed to StoryEditor on mobile — BubbleMenu suppressed entirely
- `applyVoiceTag`, `autoTagSelection`, `removeVoiceTag`, `insertSegmentBreak` added to `defineExpose`

### BubbleMenu overflow dropdown (desktop)
- First 3 role chips always visible inline
- 4+ roles → `+N ▾` toggle button opens absolute dropdown below bubble
- `CHIP_LIMIT = 3` constant controls threshold
- `chipDropdownOpen` closes automatically when bubble hides (shouldShowBubble returns false)
- CSS: `.bubble-overflow`, `.bubble-overflow__toggle`, `.bubble-overflow__dropdown`

### Edge swipe prevention (App.vue)
```css
html, body { overscroll-behavior-x: none; }  /* Android Chrome */
```
```javascript
// iOS: block touchstart in outer 10% edges, but exempt interactive elements
function onEdgeTouch(e) {
  if (e.touches.length !== 1) return
  if (e.target.closest('button, a, input, select, textarea, [role="button"]')) return
  const x = e.touches[0].clientX
  if (x < window.innerWidth * 0.1 || x > window.innerWidth * 0.9) e.preventDefault()
}
// Only registered on mobile, passive: false required for preventDefault
```

### Offline globe (EditorView.vue mobile top bar)
- 🌐 only visible when `!isOnline` — hidden 99% of the time
- Positioned just before the ⚙ gear button in the top bar
- CSS: `filter: grayscale(1) brightness(0.5) sepia(1) hue-rotate(-30deg) saturate(3)` for red tint
- Old `.m-status` floating dots div and all dot CSS removed

### Persistent CSS problem — root cause & fix
**Problem:** Every session patches EditorView.vue from the original zip. CSS added in session N is missing in session N+1 because the zip is never updated.
**Fix:** Always update SNAPSHOT.md + export a new zip at end of session. Start next session with the new zip.

### Google Drive backlog notes (discussed, not built)
Planned additions when Worker is built:
1. MD import from Drive (file picker → Worker fetch → `onMarkdownImported`)
2. Project save/load as `.storyfi` JSON to Drive (solves iOS no-File-System-Access)
3. Audio/ZIP export to Drive
Build order: Cloudflare Worker → MD import → Project save/load → Audio export
